// Admin panel main placeholder
