import 'package:flutter/material.dart';

void main() {
  runApp(const EasyRecoveryApp());
}

class EasyRecoveryApp extends StatelessWidget {
  const EasyRecoveryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Easy Recovery',
      home: Scaffold(
        appBar: AppBar(title: const Text("Easy Recovery")),
        body: const Center(child: Text("App Loaded")),
      ),
    );
  }
}
